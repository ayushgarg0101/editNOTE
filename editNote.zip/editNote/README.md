# Simple Text Editor for Android

This is simple text editor that can help you with editing text files. 

It is available on [Android Market](https://play.google.com/store/apps/details?id=com.maxistar.textpad)

This editor mostly used by me for small text notes, write down ideas while I have a break.

Supports only plain text files at the moment.

The code is open so can review code, send pull requests, new features, translations and so on. https://github.com/maxistar/TextPad.

Any suggestions, pull requests, translations for this project are welcomed. Thank you!

# How to run sniffer

./gradlew lint